package com.example.practice.model

class User(var id :String,
           var title:String,
           var body:String)